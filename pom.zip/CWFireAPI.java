package ru.cwfire.api;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import ru.cwfire.model.DeviceState;
import ru.cwfire.model.DeviceType;
import ru.cwfire.model.FireBuilding;
import ru.cwfire.model.FireDevice;

import java.util.Collection;
import java.util.Optional;
import java.util.UUID;

/**
 * Публичный API плагина CWFire.
 * Позволяет другим плагинам взаимодействовать с системой пожарной сигнализации,
 * добавлять новые типы устройств и реагировать на события тревоги.
 *
 * <p>Получение экземпляра:</p>
 * <pre>{@code
 * CWFirePlugin plugin = (CWFirePlugin) Bukkit.getPluginManager().getPlugin("CWFire");
 * CWFireAPI api = plugin.getApi();
 * }</pre>
 */
public interface CWFireAPI {

    // ==================== Устройства ====================

    /**
     * Размещает устройство в мире.
     *
     * @param type      тип устройства
     * @param location  позиция
     * @param owner     игрок-владелец
     * @return созданное устройство
     * @throws IllegalArgumentException если позиция уже занята другим устройством
     */
    FireDevice placeDevice(DeviceType type, Location location, Player owner);

    /**
     * Удаляет устройство по UUID.
     *
     * @param deviceUuid UUID устройства
     * @return true если устройство удалено
     */
    boolean removeDevice(UUID deviceUuid);

    /**
     * Находит устройство по UUID.
     *
     * @param deviceUuid UUID устройства
     * @return Optional с устройством
     */
    Optional<FireDevice> getDevice(UUID deviceUuid);

    /**
     * Находит устройство по позиции в мире.
     *
     * @param location позиция блока
     * @return Optional с устройством
     */
    Optional<FireDevice> getDeviceAt(Location location);

    /**
     * Возвращает все устройства в системе.
     *
     * @return неизменяемая коллекция устройств
     */
    Collection<FireDevice> getAllDevices();

    /**
     * Возвращает все устройства в указанном здании.
     *
     * @param buildingUuid UUID здания
     * @return коллекция устройств
     */
    Collection<FireDevice> getDevicesInBuilding(UUID buildingUuid);

    /**
     * Изменяет состояние устройства.
     *
     * @param deviceUuid UUID устройства
     * @param state      новое состояние
     */
    void setDeviceState(UUID deviceUuid, DeviceState state);

    // ==================== Здания ====================

    /**
     * Создаёт новое здание.
     *
     * @param name      название здания
     * @param owner     игрок-владелец
     * @return созданное здание
     * @throws IllegalArgumentException если здание с таким именем уже существует
     */
    FireBuilding createBuilding(String name, Player owner);

    /**
     * Удаляет здание по UUID.
     *
     * @param buildingUuid UUID здания
     * @return true если здание удалено
     */
    boolean removeBuilding(UUID buildingUuid);

    /**
     * Находит здание по UUID.
     *
     * @param buildingUuid UUID здания
     * @return Optional со зданием
     */
    Optional<FireBuilding> getBuilding(UUID buildingUuid);

    /**
     * Находит здание по названию (без учёта регистра).
     *
     * @param name название здания
     * @return Optional со зданием
     */
    Optional<FireBuilding> getBuildingByName(String name);

    /**
     * Возвращает все здания.
     *
     * @return неизменяемая коллекция зданий
     */
    Collection<FireBuilding> getAllBuildings();

    /**
     * Привязывает устройство к зданию.
     *
     * @param deviceUuid   UUID устройства
     * @param buildingUuid UUID здания
     * @return true если успешно привязано
     */
    boolean assignDeviceToBuilding(UUID deviceUuid, UUID buildingUuid);

    // ==================== Тревога ====================

    /**
     * Вручную активирует тревогу в здании.
     *
     * @param buildingUuid      UUID здания
     * @param triggerDeviceUuid UUID устройства-инициатора (может быть null)
     */
    void triggerAlarm(UUID buildingUuid, UUID triggerDeviceUuid);

    /**
     * Сбрасывает тревогу в здании.
     *
     * @param buildingUuid UUID здания
     */
    void resetAlarm(UUID buildingUuid);

    /**
     * Проверяет, активна ли тревога в здании.
     *
     * @param buildingUuid UUID здания
     * @return true если тревога активна
     */
    boolean isAlarmActive(UUID buildingUuid);

    // ==================== Связи ====================

    /**
     * Создаёт связь между двумя устройствами.
     *
     * @param fromUuid UUID первого устройства
     * @param toUuid   UUID второго устройства
     * @return true если связь создана
     */
    boolean linkDevices(UUID fromUuid, UUID toUuid);

    /**
     * Разрывает связь между двумя устройствами.
     *
     * @param fromUuid UUID первого устройства
     * @param toUuid   UUID второго устройства
     * @return true если связь разорвана
     */
    boolean unlinkDevices(UUID fromUuid, UUID toUuid);

    // ==================== Регистрация обработчиков ====================

    /**
     * Регистрирует обработчик событий тревоги.
     * Обработчик будет вызван при активации и сбросе тревоги.
     *
     * @param handler обработчик событий
     */
    void registerAlarmHandler(AlarmEventHandler handler);

    /**
     * Снимает регистрацию обработчика событий тревоги.
     *
     * @param handler обработчик событий
     */
    void unregisterAlarmHandler(AlarmEventHandler handler);

    /**
     * Регистрирует поставщика устройств (для добавления новых типов устройств).
     *
     * @param type     тип устройства
     * @param provider поставщик
     */
    void registerDeviceProvider(DeviceType type, DeviceProvider provider);

    /**
     * Принудительно сохраняет все данные плагина.
     */
    void saveAll();
}
