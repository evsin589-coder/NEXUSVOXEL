package ru.cwfire.model;

/**
 * Перечисление возможных состояний устройства пожарной сигнализации.
 */
public enum DeviceState {

    /** Нормальное рабочее состояние — тревоги нет */
    NORMAL,

    /** Состояние пожара — устройство активировано тревогой */
    FIRE,

    /** Неисправность — устройство не функционирует должным образом */
    FAULT,

    /** Отключено — устройство принудительно деактивировано */
    DISABLED;

    /**
     * Пытается найти состояние по строковому имени (без учёта регистра).
     *
     * @param name строка с именем состояния
     * @return найденное состояние или NORMAL по умолчанию
     */
    public static DeviceState fromString(String name) {
        if (name == null) return NORMAL;
        for (DeviceState state : values()) {
            if (state.name().equalsIgnoreCase(name)) {
                return state;
            }
        }
        return NORMAL;
    }

    /**
     * Возвращает ключ для получения цвета состояния из локализации.
     *
     * @return ключ цвета
     */
    public String getColorKey() {
        return "state-colors." + this.name();
    }

    /**
     * Возвращает ключ для получения названия состояния из локализации.
     *
     * @return ключ названия
     */
    public String getLangKey() {
        return "device-states." + this.name();
    }
}
