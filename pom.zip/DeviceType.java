package ru.cwfire.model;

import org.bukkit.Material;

/**
 * Перечисление типов устройств пожарной сигнализации.
 * Каждый тип имеет связанный материал блока и ключ локализации.
 */
public enum DeviceType {

    /** Пожарная панель управления */
    PANEL(Material.CRIMSON_PRESSURE_PLATE, "cwfire.device.type.panel"),

    /** Ручной пожарный извещатель */
    DETECTOR(Material.STONE_BUTTON, "cwfire.device.type.detector"),

    /** Пожарная сирена */
    SIREN(Material.NOTE_BLOCK, "cwfire.device.type.siren"),

    /** Речевой оповещатель */
    VOICE_ANNOUNCER(Material.JUKEBOX, "cwfire.device.type.voice_announcer"),

    /** Табло «Выход» */
    EXIT_SIGN(Material.GLOWSTONE, "cwfire.device.type.exit_sign");

    /** Материал, используемый в качестве блока устройства */
    private final Material blockMaterial;

    /** Ключ локализации для отображения названия */
    private final String langKey;

    DeviceType(Material blockMaterial, String langKey) {
        this.blockMaterial = blockMaterial;
        this.langKey = langKey;
    }

    /**
     * Возвращает материал блока, который визуально представляет устройство.
     *
     * @return материал блока
     */
    public Material getBlockMaterial() {
        return blockMaterial;
    }

    /**
     * Возвращает ключ локализации для названия типа.
     *
     * @return ключ локализации
     */
    public String getLangKey() {
        return langKey;
    }

    /**
     * Пытается найти тип устройства по строковому имени (без учёта регистра).
     *
     * @param name строка с именем типа
     * @return найденный тип или null
     */
    public static DeviceType fromString(String name) {
        for (DeviceType type : values()) {
            if (type.name().equalsIgnoreCase(name)) {
                return type;
            }
        }
        return null;
    }
}
