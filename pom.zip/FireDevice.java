package ru.cwfire.model;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;

import java.util.*;

/**
 * Модель устройства пожарной сигнализации.
 * Хранит всю информацию об одном устройстве: тип, состояние, положение, связи, метаданные.
 */
public class FireDevice {

    /** Уникальный идентификатор устройства */
    private final UUID uuid;

    /** Тип устройства */
    private final DeviceType type;

    /** Имя мира, в котором размещено устройство */
    private final String worldName;

    /** Координаты блока устройства */
    private final int x;
    private final int y;
    private final int z;

    /** Отображаемое название устройства */
    private String name;

    /** UUID владельца (игрока, установившего устройство) */
    private UUID ownerUuid;

    /** Имя владельца (для отображения, т.к. игрок может быть офлайн) */
    private String ownerName;

    /** Текущее состояние устройства */
    private DeviceState state;

    /** UUID здания, к которому привязано устройство */
    private UUID buildingUuid;

    /** UUID устройств, с которыми установлена связь */
    private final Set<UUID> linkedDevices;

    /** Дополнительные данные устройства (зависят от типа) */
    private final Map<String, Object> metadata;

    /**
     * Создаёт новое устройство с генерацией UUID.
     *
     * @param type      тип устройства
     * @param location  позиция в мире
     * @param ownerUuid UUID владельца
     * @param ownerName имя владельца
     */
    public FireDevice(DeviceType type, Location location, UUID ownerUuid, String ownerName) {
        this.uuid = UUID.randomUUID();
        this.type = type;
        this.worldName = location.getWorld().getName();
        this.x = location.getBlockX();
        this.y = location.getBlockY();
        this.z = location.getBlockZ();
        this.name = type.name() + "_" + uuid.toString().substring(0, 8);
        this.ownerUuid = ownerUuid;
        this.ownerName = ownerName;
        this.state = DeviceState.NORMAL;
        this.buildingUuid = null;
        this.linkedDevices = new HashSet<>();
        this.metadata = new HashMap<>();
    }

    /**
     * Конструктор для десериализации из YAML.
     */
    public FireDevice(UUID uuid, DeviceType type, String worldName, int x, int y, int z,
                      String name, UUID ownerUuid, String ownerName, DeviceState state,
                      UUID buildingUuid, Set<UUID> linkedDevices, Map<String, Object> metadata) {
        this.uuid = uuid;
        this.type = type;
        this.worldName = worldName;
        this.x = x;
        this.y = y;
        this.z = z;
        this.name = name;
        this.ownerUuid = ownerUuid;
        this.ownerName = ownerName;
        this.state = state;
        this.buildingUuid = buildingUuid;
        this.linkedDevices = new HashSet<>(linkedDevices);
        this.metadata = new HashMap<>(metadata);
    }

    // ==================== Геттеры ====================

    public UUID getUuid() { return uuid; }

    public DeviceType getType() { return type; }

    public String getWorldName() { return worldName; }

    public int getX() { return x; }

    public int getY() { return y; }

    public int getZ() { return z; }

    public String getName() { return name; }

    public UUID getOwnerUuid() { return ownerUuid; }

    public String getOwnerName() { return ownerName; }

    public DeviceState getState() { return state; }

    public UUID getBuildingUuid() { return buildingUuid; }

    public Set<UUID> getLinkedDevices() { return Collections.unmodifiableSet(linkedDevices); }

    public Map<String, Object> getMetadata() { return Collections.unmodifiableMap(metadata); }

    // ==================== Сеттеры ====================

    public void setName(String name) { this.name = name; }

    public void setOwnerUuid(UUID ownerUuid) { this.ownerUuid = ownerUuid; }

    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }

    public void setState(DeviceState state) { this.state = state; }

    public void setBuildingUuid(UUID buildingUuid) { this.buildingUuid = buildingUuid; }

    // ==================== Работа со связями ====================

    /**
     * Добавляет связь с другим устройством.
     *
     * @param targetUuid UUID целевого устройства
     * @return true если связь добавлена, false если уже существует
     */
    public boolean addLink(UUID targetUuid) {
        return linkedDevices.add(targetUuid);
    }

    /**
     * Удаляет связь с устройством.
     *
     * @param targetUuid UUID целевого устройства
     * @return true если связь была и удалена
     */
    public boolean removeLink(UUID targetUuid) {
        return linkedDevices.remove(targetUuid);
    }

    /**
     * Проверяет наличие связи с указанным устройством.
     *
     * @param targetUuid UUID целевого устройства
     * @return true если связь существует
     */
    public boolean isLinkedTo(UUID targetUuid) {
        return linkedDevices.contains(targetUuid);
    }

    // ==================== Работа с метаданными ====================

    /**
     * Устанавливает значение метаданных.
     *
     * @param key   ключ
     * @param value значение
     */
    public void setMetadata(String key, Object value) {
        metadata.put(key, value);
    }

    /**
     * Возвращает значение метаданных по ключу.
     *
     * @param key ключ
     * @return значение или null
     */
    public Object getMetadata(String key) {
        return metadata.get(key);
    }

    /**
     * Возвращает значение метаданных как строку.
     *
     * @param key          ключ
     * @param defaultValue значение по умолчанию
     * @return строковое значение
     */
    public String getMetadataString(String key, String defaultValue) {
        Object val = metadata.get(key);
        return val != null ? val.toString() : defaultValue;
    }

    // ==================== Вспомогательные методы ====================

    /**
     * Возвращает объект Location для данного устройства.
     * Может вернуть null, если мир не загружен.
     *
     * @return Location или null
     */
    public Location getLocation() {
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;
        return new Location(world, x, y, z);
    }

    /**
     * Проверяет, совпадает ли переданная позиция с позицией устройства.
     *
     * @param location проверяемая позиция
     * @return true если совпадает
     */
    public boolean isAtLocation(Location location) {
        if (!location.getWorld().getName().equals(worldName)) return false;
        return location.getBlockX() == x
                && location.getBlockY() == y
                && location.getBlockZ() == z;
    }

    /**
     * Сериализует устройство в ConfigurationSection для сохранения в YAML.
     *
     * @param section раздел конфигурации
     */
    public void serialize(ConfigurationSection section) {
        section.set("uuid", uuid.toString());
        section.set("type", type.name());
        section.set("world", worldName);
        section.set("x", x);
        section.set("y", y);
        section.set("z", z);
        section.set("name", name);
        section.set("owner-uuid", ownerUuid.toString());
        section.set("owner-name", ownerName);
        section.set("state", state.name());
        section.set("building-uuid", buildingUuid != null ? buildingUuid.toString() : null);

        List<String> links = new ArrayList<>();
        for (UUID link : linkedDevices) {
            links.add(link.toString());
        }
        section.set("links", links);

        // Сохраняем метаданные
        for (Map.Entry<String, Object> entry : metadata.entrySet()) {
            section.set("metadata." + entry.getKey(), entry.getValue());
        }
    }

    /**
     * Десериализует устройство из ConfigurationSection.
     *
     * @param section раздел конфигурации
     * @return объект FireDevice или null при ошибке
     */
    public static FireDevice deserialize(ConfigurationSection section) {
        try {
            UUID uuid = UUID.fromString(section.getString("uuid"));
            DeviceType type = DeviceType.valueOf(section.getString("type"));
            String worldName = section.getString("world");
            int x = section.getInt("x");
            int y = section.getInt("y");
            int z = section.getInt("z");
            String name = section.getString("name", "Unknown");
            UUID ownerUuid = UUID.fromString(section.getString("owner-uuid", UUID.randomUUID().toString()));
            String ownerName = section.getString("owner-name", "Unknown");
            DeviceState state = DeviceState.fromString(section.getString("state"));

            String buildingStr = section.getString("building-uuid");
            UUID buildingUuid = (buildingStr != null && !buildingStr.isEmpty())
                    ? UUID.fromString(buildingStr) : null;

            Set<UUID> linkedDevices = new HashSet<>();
            List<String> linksList = section.getStringList("links");
            for (String link : linksList) {
                try {
                    linkedDevices.add(UUID.fromString(link));
                } catch (IllegalArgumentException ignored) {
                    // Пропускаем некорректные UUID
                }
            }

            Map<String, Object> metadata = new HashMap<>();
            ConfigurationSection metaSection = section.getConfigurationSection("metadata");
            if (metaSection != null) {
                for (String key : metaSection.getKeys(false)) {
                    metadata.put(key, metaSection.get(key));
                }
            }

            return new FireDevice(uuid, type, worldName, x, y, z, name,
                    ownerUuid, ownerName, state, buildingUuid, linkedDevices, metadata);

        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FireDevice other)) return false;
        return uuid.equals(other.uuid);
    }

    @Override
    public int hashCode() {
        return uuid.hashCode();
    }

    @Override
    public String toString() {
        return "FireDevice{uuid=" + uuid + ", type=" + type + ", name='" + name + "', state=" + state + "}";
    }
}
