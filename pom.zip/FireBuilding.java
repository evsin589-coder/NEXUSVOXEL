package ru.cwfire.model;

import org.bukkit.configuration.ConfigurationSection;

import java.util.*;

/**
 * Модель здания — независимой зоны пожарной сигнализации.
 * Каждое здание может иметь множество устройств и собственное состояние тревоги.
 */
public class FireBuilding {

    /** Уникальный идентификатор здания */
    private final UUID uuid;

    /** Отображаемое название здания */
    private String name;

    /** UUID владельца здания */
    private UUID ownerUuid;

    /** Имя владельца для отображения */
    private String ownerName;

    /** Текущее агрегированное состояние здания */
    private DeviceState state;

    /** UUID всех устройств, привязанных к этому зданию */
    private final Set<UUID> deviceUuids;

    /** Флаг активной тревоги */
    private boolean alarmActive;

    /** UUID устройства, инициировавшего тревогу (для отображения в панели) */
    private UUID triggerDeviceUuid;

    /** Время начала тревоги (мс) */
    private long alarmStartTime;

    /**
     * Создаёт новое здание.
     *
     * @param name      название здания
     * @param ownerUuid UUID владельца
     * @param ownerName имя владельца
     */
    public FireBuilding(String name, UUID ownerUuid, String ownerName) {
        this.uuid = UUID.randomUUID();
        this.name = name;
        this.ownerUuid = ownerUuid;
        this.ownerName = ownerName;
        this.state = DeviceState.NORMAL;
        this.deviceUuids = new HashSet<>();
        this.alarmActive = false;
        this.triggerDeviceUuid = null;
        this.alarmStartTime = 0L;
    }

    /**
     * Конструктор для десериализации из YAML.
     */
    public FireBuilding(UUID uuid, String name, UUID ownerUuid, String ownerName,
                        DeviceState state, Set<UUID> deviceUuids, boolean alarmActive,
                        UUID triggerDeviceUuid, long alarmStartTime) {
        this.uuid = uuid;
        this.name = name;
        this.ownerUuid = ownerUuid;
        this.ownerName = ownerName;
        this.state = state;
        this.deviceUuids = new HashSet<>(deviceUuids);
        this.alarmActive = alarmActive;
        this.triggerDeviceUuid = triggerDeviceUuid;
        this.alarmStartTime = alarmStartTime;
    }

    // ==================== Геттеры ====================

    public UUID getUuid() { return uuid; }

    public String getName() { return name; }

    public UUID getOwnerUuid() { return ownerUuid; }

    public String getOwnerName() { return ownerName; }

    public DeviceState getState() { return state; }

    public Set<UUID> getDeviceUuids() { return Collections.unmodifiableSet(deviceUuids); }

    public boolean isAlarmActive() { return alarmActive; }

    public UUID getTriggerDeviceUuid() { return triggerDeviceUuid; }

    public long getAlarmStartTime() { return alarmStartTime; }

    // ==================== Сеттеры ====================

    public void setName(String name) { this.name = name; }

    public void setOwnerUuid(UUID ownerUuid) { this.ownerUuid = ownerUuid; }

    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }

    public void setState(DeviceState state) { this.state = state; }

    public void setAlarmActive(boolean alarmActive) { this.alarmActive = alarmActive; }

    public void setTriggerDeviceUuid(UUID triggerDeviceUuid) { this.triggerDeviceUuid = triggerDeviceUuid; }

    public void setAlarmStartTime(long alarmStartTime) { this.alarmStartTime = alarmStartTime; }

    // ==================== Работа с устройствами ====================

    /**
     * Добавляет UUID устройства в здание.
     *
     * @param deviceUuid UUID устройства
     * @return true если добавлено
     */
    public boolean addDevice(UUID deviceUuid) {
        return deviceUuids.add(deviceUuid);
    }

    /**
     * Удаляет UUID устройства из здания.
     *
     * @param deviceUuid UUID устройства
     * @return true если удалено
     */
    public boolean removeDevice(UUID deviceUuid) {
        return deviceUuids.remove(deviceUuid);
    }

    /**
     * Проверяет, принадлежит ли устройство этому зданию.
     *
     * @param deviceUuid UUID устройства
     * @return true если принадлежит
     */
    public boolean hasDevice(UUID deviceUuid) {
        return deviceUuids.contains(deviceUuid);
    }

    /**
     * Возвращает количество устройств в здании.
     *
     * @return количество устройств
     */
    public int getDeviceCount() {
        return deviceUuids.size();
    }

    /**
     * Активирует тревогу в здании.
     *
     * @param triggerDeviceUuid UUID устройства, инициировавшего тревогу
     */
    public void activateAlarm(UUID triggerDeviceUuid) {
        this.alarmActive = true;
        this.triggerDeviceUuid = triggerDeviceUuid;
        this.alarmStartTime = System.currentTimeMillis();
        this.state = DeviceState.FIRE;
    }

    /**
     * Сбрасывает тревогу и переводит здание в нормальное состояние.
     */
    public void resetAlarm() {
        this.alarmActive = false;
        this.triggerDeviceUuid = null;
        this.alarmStartTime = 0L;
        this.state = DeviceState.NORMAL;
    }

    // ==================== Сериализация ====================

    /**
     * Сериализует здание в ConfigurationSection.
     *
     * @param section раздел конфигурации
     */
    public void serialize(ConfigurationSection section) {
        section.set("uuid", uuid.toString());
        section.set("name", name);
        section.set("owner-uuid", ownerUuid.toString());
        section.set("owner-name", ownerName);
        section.set("state", state.name());
        section.set("alarm-active", alarmActive);
        section.set("trigger-device", triggerDeviceUuid != null ? triggerDeviceUuid.toString() : null);
        section.set("alarm-start", alarmStartTime);

        List<String> devices = new ArrayList<>();
        for (UUID deviceUuid : deviceUuids) {
            devices.add(deviceUuid.toString());
        }
        section.set("devices", devices);
    }

    /**
     * Десериализует здание из ConfigurationSection.
     *
     * @param section раздел конфигурации
     * @return объект FireBuilding или null при ошибке
     */
    public static FireBuilding deserialize(ConfigurationSection section) {
        try {
            UUID uuid = UUID.fromString(section.getString("uuid"));
            String name = section.getString("name", "Unknown");
            UUID ownerUuid = UUID.fromString(section.getString("owner-uuid", UUID.randomUUID().toString()));
            String ownerName = section.getString("owner-name", "Unknown");
            DeviceState state = DeviceState.fromString(section.getString("state"));
            boolean alarmActive = section.getBoolean("alarm-active", false);

            String triggerStr = section.getString("trigger-device");
            UUID triggerDeviceUuid = (triggerStr != null && !triggerStr.isEmpty())
                    ? UUID.fromString(triggerStr) : null;

            long alarmStartTime = section.getLong("alarm-start", 0L);

            Set<UUID> deviceUuids = new HashSet<>();
            List<String> deviceList = section.getStringList("devices");
            for (String deviceStr : deviceList) {
                try {
                    deviceUuids.add(UUID.fromString(deviceStr));
                } catch (IllegalArgumentException ignored) {
                    // Пропускаем некорректные UUID
                }
            }

            return new FireBuilding(uuid, name, ownerUuid, ownerName, state,
                    deviceUuids, alarmActive, triggerDeviceUuid, alarmStartTime);

        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FireBuilding other)) return false;
        return uuid.equals(other.uuid);
    }

    @Override
    public int hashCode() {
        return uuid.hashCode();
    }

    @Override
    public String toString() {
        return "FireBuilding{uuid=" + uuid + ", name='" + name + "', state=" + state + ", devices=" + deviceUuids.size() + "}";
    }
}
